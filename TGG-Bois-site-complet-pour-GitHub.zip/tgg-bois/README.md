# TGG Bois — site vitrine et administration

Projet React + Vite + TypeScript, conçu pour le site TGG Bois. Le catalogue ne contient aucun produit fictif : seules les catégories de meubles sont préchargées.

## Configuration Supabase

Le projet utilise ces variables d'environnement :
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_PUBLISHABLE_KEY` (clé publique `sb_publishable_...` uniquement)
- `VITE_WHATSAPP_NUMBER` (facultatif)

L'URL du nouveau projet est déjà renseignée dans `.env.example`. La clé publique reste un espace réservé : ajoute-la dans les variables de l'hébergeur, pas dans un dépôt public. Ne jamais utiliser `service_role` ou une clé `secret` dans le navigateur.

Le script de structure est dans `supabase/migrations/202610270001_tgg_bois_schema.sql`. Comme la base a déjà été créée via SQL Editor, ne relance pas ce script sur cette base sans vérifier l'état actuel ; il est fourni pour référence/recréation.

## Build

- Build command: `npm run build`
- Publish directory: `dist`

## WhatsApp

Le numéro officiel en production est configuré dans `src/lib/config.ts` : +237 679 78 05 76. Le numéro de test est utilisé en développement.

## Publication depuis iPhone

1. Décompresser le ZIP dans l'application Fichiers.
2. Créer un dépôt GitHub vide.
3. Importer les fichiers et dossiers du projet à la racine du dépôt (pas uniquement le ZIP).
4. Connecter le dépôt à Netlify et définir les variables d'environnement dans les paramètres du site.

Ne publie pas de fichier `.env` contenant une clé. Le `.gitignore` exclut déjà `.env`.
