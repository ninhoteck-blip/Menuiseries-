/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        forest: { DEFAULT: '#1F3D2F', dark: '#162C22', soft: '#B9CDBE' },
        ivory: '#F7F4EC',
        cream: '#EFEADF',
        sand: '#E3D9C6',
        wood: '#8A5A3B',
      },
      fontFamily: {
        serif: ['Fraunces', 'Georgia', 'serif'],
        sans: ['"DM Sans"', 'system-ui', 'sans-serif'],
      },
      boxShadow: { card: '0 10px 40px -12px rgba(31,61,47,.18)' },
    },
  },
  plugins: [],
};
