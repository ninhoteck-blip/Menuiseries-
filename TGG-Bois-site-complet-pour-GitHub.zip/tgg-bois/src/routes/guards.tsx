import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useI18n } from '../i18n';

function Splash() {
  const { t } = useI18n();
  return <div className="grid min-h-screen place-items-center text-forest/70" role="status">{t('common.loading')}</div>;
}

/** Réservé aux utilisateurs connectés (session Supabase vérifiée). */
export function ProtectedRoute() {
  const { session, loading } = useAuth();
  const loc = useLocation();
  if (loading) return <Splash />;
  if (!session) return <Navigate to="/login" replace state={{ from: loc.pathname }} />;
  return <Outlet />;
}

/** Réservé à l'admin. Confort d'interface seulement : RLS protège réellement les données. */
export function AdminRoute() {
  const { isAdmin, loading } = useAuth();
  if (loading) return <Splash />;
  if (!isAdmin) return <Navigate to="/" replace />;
  return <Outlet />;
}

/** Pages de connexion : redirige vers la vitrine si déjà connecté. */
export function GuestRoute() {
  const { session, loading } = useAuth();
  if (loading) return <Splash />;
  if (session) return <Navigate to="/" replace />;
  return <Outlet />;
}
