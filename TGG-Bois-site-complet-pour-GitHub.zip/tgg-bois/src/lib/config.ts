// Configuration centralisée. Le numéro WhatsApp est choisi ici et nulle part ailleurs.
const OFFICIAL = '237679780576'; // numéro officiel TGG Bois
const TEST = '237695657754';     // numéro de test (développement)

const override = (import.meta.env.VITE_WHATSAPP_NUMBER as string | undefined)?.replace(/\D/g, '');
export const WHATSAPP_NUMBER = override || (import.meta.env.PROD ? OFFICIAL : TEST);
