import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useI18n } from '../../i18n';
import { formatPrice, useQuery, type Product, type ProductImage as Img } from '../../lib/data';
import { supabase } from '../../lib/supabase';
import { whatsappUrl } from '../../lib/whatsapp';
import Async from '../../components/Async';
import { AvailabilityBadge, ProductImage } from '../../components/ProductCard';

export default function ProductDetail() {
  const { t } = useI18n();
  const id = Number(useParams().id);
  const [qty, setQty] = useState(1);
  const [sel, setSel] = useState(0);
  const prod = useQuery<Product>(() => supabase.from('products').select('*').eq('id', id).maybeSingle(), [id]);
  const imgs = useQuery<Img[]>(() => supabase.from('product_images').select('*').eq('product_id', id).order('sort_order'), [id]);
  const p = prod.data;
  const urls = imgs.data?.length ? imgs.data.map((i) => i.url) : p?.image_url ? [p.image_url] : [];

  let wa: string | null = null;
  if (p) {
    const msg = [t('wa.greeting'), `${t('wa.product')} : ${p.name}`, `${t('wa.ref')} : TGG-${p.id}`,
      `${t('wa.price')} : ${formatPrice(p.price) ?? t('product.priceOnRequest')}`, `${t('wa.link')} : ${window.location.origin}/product/${p.id}`, `${t('wa.qty')} : ${qty}`].join('\n');
    wa = whatsappUrl(msg);
  }
  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <Link to="/catalog" className="text-sm font-medium text-forest hover:underline">← {t('product.back')}</Link>
      <div className="mt-4">
        <Async loading={prod.loading} error={prod.error} onRetry={prod.reload}>
          {!p ? <p className="py-16 text-center text-forest/70">{t('product.notFound')}</p> : (
            <div className="grid gap-8 md:grid-cols-2">
              <div>
                <ProductImage src={urls[sel] ?? null} alt={p.name ?? ''} className="aspect-square w-full rounded-3xl" />
                {urls.length > 1 && <div className="mt-3 flex gap-2 overflow-x-auto">{urls.map((u, i) => (
                  <button key={u} onClick={() => setSel(i)} className={`h-16 w-16 shrink-0 overflow-hidden rounded-xl border-2 ${i === sel ? 'border-forest' : 'border-transparent'}`}><img src={u} alt="" className="h-full w-full object-cover" /></button>
                ))}</div>}
              </div>
              <div className="space-y-4">
                <h1 className="text-3xl text-forest md:text-4xl">{p.name}</h1>
                <p className="text-2xl font-medium">{formatPrice(p.price) ?? t('product.priceOnRequest')}</p>
                <div className="flex items-center gap-3"><AvailabilityBadge value={p.availability} /><span className="text-sm text-forest/60">{t('product.ref')} TGG-{p.id}</span></div>
                {p.description && <p className="whitespace-pre-line text-forest/80">{p.description}</p>}
                <div className="flex items-center gap-3">
                  <span className="text-sm font-medium">{t('product.qty')}</span>
                  <button aria-label="-" onClick={() => setQty((q) => Math.max(1, q - 1))} className="h-10 w-10 rounded-full bg-cream text-lg">−</button>
                  <span className="w-8 text-center font-medium">{qty}</span>
                  <button aria-label="+" onClick={() => setQty((q) => Math.min(99, q + 1))} className="h-10 w-10 rounded-full bg-cream text-lg">+</button>
                </div>
                {wa && p.availability !== 'unavailable'
                  ? <a href={wa} target="_blank" rel="noopener noreferrer" className="block rounded-xl bg-forest py-4 text-center font-medium text-ivory hover:bg-forest-dark">{t('product.order')}</a>
                  : <span className="block rounded-xl bg-stone-200 py-4 text-center font-medium text-stone-500">{t('product.order')}</span>}
              </div>
            </div>
          )}
        </Async>
      </div>
    </div>
  );
}
