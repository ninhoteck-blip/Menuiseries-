import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useI18n } from '../../i18n';
import { formatPrice, useProducts, type Product } from '../../lib/data';
import { supabase } from '../../lib/supabase';
import Async from '../../components/Async';
import { ProductImage } from '../../components/ProductCard';
import { Notice } from '../../components/ui';

export default function Products() {
  const { t } = useI18n();
  const prods = useProducts(true);
  const [err, setErr] = useState('');

  async function toggle(p: Product) {
    setErr('');
    const { error } = await supabase.from('products').update({ is_active: !p.is_active, updated_at: new Date().toISOString() }).eq('id', p.id);
    if (error) setErr(t('f.err.save')); else prods.reload();
  }
  async function remove(p: Product) {
    if (!window.confirm(t('f.confirmDelete'))) return;
    setErr('');
    const { data } = await supabase.from('product_images').select('storage_path').eq('product_id', p.id);
    if (data?.length) await supabase.storage.from('product-images').remove(data.map((d) => d.storage_path));
    const { error } = await supabase.from('products').delete().eq('id', p.id);
    if (error) setErr(t('f.err.save')); else prods.reload();
  }
  const btn = 'rounded-lg px-3 py-2 text-sm font-medium hover:bg-sand/60';
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between"><h1 className="text-3xl text-forest">{t('admin.products')}</h1>
        <Link to="/admin/products/new" className="rounded-full bg-forest px-5 py-2.5 text-sm font-medium text-ivory">+ {t('admin.add')}</Link></div>
      {err && <Notice kind="error">{err}</Notice>}
      <Async loading={prods.loading} error={prods.error} onRetry={prods.reload}>
        {(prods.data ?? []).length === 0 ? <p className="rounded-3xl bg-white p-8 text-center text-forest/70">{t('admin.empty')}</p> : (
          <div className="overflow-x-auto rounded-3xl bg-white p-3 shadow-card">
            <table className="w-full min-w-[640px] text-left text-sm">
              <thead className="text-forest/60"><tr>{['table.name', 'table.price', 'table.stock', 'table.status', 'table.actions'].map((k) => <th key={k} className="px-3 py-2 font-medium">{t(k as never)}</th>)}</tr></thead>
              <tbody className="divide-y divide-sand">{(prods.data ?? []).map((p) => (
                <tr key={p.id}>
                  <td className="px-3 py-3"><div className="flex items-center gap-3"><ProductImage src={p.image_url} alt="" className="h-12 w-12 rounded-lg text-[0px]" /><span className="font-medium">{p.name}</span></div></td>
                  <td className="px-3">{formatPrice(p.price)}</td><td className="px-3">{p.stock}</td>
                  <td className="px-3"><span className={`rounded-full px-3 py-1 text-xs ${p.is_active ? 'bg-emerald-100 text-emerald-900' : 'bg-stone-200 text-stone-700'}`}>{p.is_active ? t('f.status.active') : t('f.status.inactive')}</span></td>
                  <td className="px-3"><div className="flex flex-wrap">
                    <Link to={`/admin/products/${p.id}/edit`} className={btn}>{t('f.editBtn')}</Link>
                    <button onClick={() => toggle(p)} className={btn}>{p.is_active ? t('f.deactivate') : t('f.activate')}</button>
                    <button onClick={() => remove(p)} className={`${btn} text-red-700`}>{t('f.delete')}</button></div></td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        )}
      </Async>
    </div>
  );
}
