import { useState } from 'react';
import { Link, NavLink, Outlet } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useI18n } from '../../i18n';
import { LangSwitch, Logo } from '../../components/ui';

export default function AdminLayout() {
  const { t } = useI18n();
  const { signOut } = useAuth();
  const [open, setOpen] = useState(false);
  const items = [['/admin', '📊', 'admin.overview', true], ['/admin/products', '📦', 'admin.products', false], ['/admin/products/new', '➕', 'admin.add', false], ['/admin/categories', '🏷️', 'admin.categories', false]] as const;
  return (
    <div className="min-h-screen bg-stone-100 md:flex">
      <header className="flex items-center justify-between bg-forest-dark px-4 py-3 md:hidden">
        <Logo light />
        <button aria-label={t('admin.menu')} onClick={() => setOpen(true)} className="h-10 w-10 rounded-lg text-2xl text-ivory">☰</button>
      </header>
      {open && <div className="fixed inset-0 z-30 bg-black/40 md:hidden" onClick={() => setOpen(false)} />}
      <aside className={`fixed inset-y-0 left-0 z-40 flex w-64 flex-col bg-forest-dark p-5 text-ivory transition-transform md:sticky md:top-0 md:h-screen md:translate-x-0 ${open ? 'translate-x-0' : '-translate-x-full'}`}>
        <Logo light />
        <nav className="mt-8 flex-1 space-y-1">
          {items.map(([to, icon, key, end]) => (
            <NavLink key={to} to={to} end={end} onClick={() => setOpen(false)} className={({ isActive }) => `flex items-center gap-3 rounded-xl px-3 py-3 text-sm ${isActive ? 'bg-forest text-white' : 'text-ivory/75 hover:bg-white/10'}`}><span aria-hidden>{icon}</span>{t(key)}</NavLink>
          ))}
          <Link to="/" className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm text-ivory/75 hover:bg-white/10"><span aria-hidden>🏠</span>{t('admin.shop')}</Link>
        </nav>
        <div className="space-y-2"><LangSwitch /><button onClick={signOut} className="block w-full rounded-xl px-3 py-3 text-left text-sm text-ivory/75 hover:bg-white/10">⎋ {t('common.logout')}</button></div>
      </aside>
      <main className="min-w-0 flex-1 p-4 md:p-8"><Outlet /></main>
    </div>
  );
}
