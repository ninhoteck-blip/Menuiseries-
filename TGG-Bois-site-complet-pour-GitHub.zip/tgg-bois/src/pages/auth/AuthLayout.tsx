import type { ReactNode } from 'react';
import { LangSwitch, Logo } from '../../components/ui';

export default function AuthLayout({ title, subtitle, children }: { title: string; subtitle: string; children: ReactNode }) {
  return (
    <main className="min-h-screen bg-ivory px-4 py-6">
      <div className="mx-auto flex max-w-md items-center justify-between"><Logo /><LangSwitch /></div>
      <div className="mx-auto mt-10 max-w-md rounded-3xl bg-white p-6 shadow-card sm:p-8">
        <h1 className="text-2xl text-forest">{title}</h1>
        <p className="mb-6 mt-1 text-sm text-forest/70">{subtitle}</p>
        {children}
      </div>
    </main>
  );
}

export const isEmail = (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim());
