import { useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import { authErrorKey, useI18n } from '../../i18n';
import { Button, Field, Notice, PasswordField } from '../../components/ui';
import AuthLayout, { isEmail } from './AuthLayout';

export default function Register() {
  const { t } = useI18n();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<{ name?: string; email?: string; password?: string }>({});
  const [formError, setFormError] = useState('');
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError('');
    const errs: typeof errors = {};
    if (name.trim().length < 2) errs.name = t('val.nameRequired');
    if (!isEmail(email)) errs.email = t('val.emailRequired');
    if (password.length < 8) errs.password = t('val.passwordMin');
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email: email.trim(), password,
      options: { data: { full_name: name.trim() }, emailRedirectTo: `${window.location.origin}/login` },
    });
    setLoading(false);
    if (error) return setFormError(t(authErrorKey(error)));
    setDone(true);
  }

  return (
    <AuthLayout title={t('auth.register.title')} subtitle={t('auth.register.subtitle')}>
      {done ? (
        <div className="space-y-4">
          <Notice kind="success">{t('auth.register.success')}</Notice>
          <Link to="/login" className="block"><Button type="button">{t('auth.login')}</Button></Link>
        </div>
      ) : (
        <form onSubmit={onSubmit} className="space-y-4" noValidate>
          <Field id="name" autoComplete="name" label={t('auth.name')} value={name} onChange={(e) => setName(e.target.value)} error={errors.name} />
          <Field id="email" type="email" autoComplete="email" label={t('auth.email')} value={email} onChange={(e) => setEmail(e.target.value)} error={errors.email} />
          <PasswordField id="password" autoComplete="new-password" label={t('auth.password')} value={password} onChange={(e) => setPassword(e.target.value)} error={errors.password} />
          {formError && <Notice kind="error">{formError}</Notice>}
          <Button type="submit" loading={loading}>{t('auth.register')}</Button>
          <Link to="/login" className="block py-2 text-center text-sm font-medium text-forest hover:underline">{t('auth.backToLogin')}</Link>
        </form>
      )}
    </AuthLayout>
  );
}
