import { useState, type FormEvent } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import { authErrorKey, useI18n } from '../../i18n';
import { Button, Field, Notice, PasswordField } from '../../components/ui';
import AuthLayout, { isEmail } from './AuthLayout';

export default function Login() {
  const { t } = useI18n();
  const nav = useNavigate();
  const from = (useLocation().state as { from?: string } | null)?.from || '/';
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});
  const [formError, setFormError] = useState('');
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError('');
    const errs: typeof errors = {};
    if (!isEmail(email)) errs.email = t('val.emailRequired');
    if (password.length < 8) errs.password = t('val.passwordMin');
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    setLoading(false);
    if (error) return setFormError(t(authErrorKey(error)));
    nav(from, { replace: true });
  }

  return (
    <AuthLayout title={t('auth.login.title')} subtitle={t('auth.login.subtitle')}>
      <form onSubmit={onSubmit} className="space-y-4" noValidate>
        <Field id="email" type="email" autoComplete="email" label={t('auth.email')} placeholder="nom@exemple.com" value={email} onChange={(e) => setEmail(e.target.value)} error={errors.email} />
        <PasswordField id="password" autoComplete="current-password" label={t('auth.password')} placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} error={errors.password} />
        {formError && <Notice kind="error">{formError}</Notice>}
        <Button type="submit" loading={loading}>{t('auth.login')}</Button>
      </form>
      <div className="mt-3 space-y-3 text-center">
        <Link to="/register" className="block"><Button type="button" variant="outline">{t('auth.register')}</Button></Link>
        <Link to="/forgot-password" className="inline-block py-2 text-sm font-medium text-forest underline-offset-4 hover:underline">{t('auth.forgot')}</Link>
      </div>
    </AuthLayout>
  );
}
