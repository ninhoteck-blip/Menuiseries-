import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

export type Role = 'customer' | 'admin';
interface AuthValue { session: Session | null; user: User | null; role: Role | null; loading: boolean; isAdmin: boolean; signOut: () => Promise<void>; }
const AuthContext = createContext<AuthValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [role, setRole] = useState<Role | null>(null);
  const [loading, setLoading] = useState(true);

  // La session vient toujours de Supabase, jamais d'une variable locale.
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); if (!data.session) setLoading(false); });
    const { data: sub } = supabase.auth.onAuthStateChange((_evt, s) => { setSession(s); if (!s) { setRole(null); setLoading(false); } });
    return () => sub.subscription.unsubscribe();
  }, []);

  // Le rôle est lu dans la base (RLS : un client ne voit que son propre rôle). Pour l'affichage uniquement :
  // la vraie protection est assurée par les politiques RLS côté serveur.
  const uid = session?.user.id;
  useEffect(() => {
    if (!uid) return;
    let cancelled = false;
    setLoading(true);
    supabase.from('user_roles').select('role').eq('user_id', uid).maybeSingle().then(({ data }) => {
      if (cancelled) return;
      setRole((data?.role as Role) ?? 'customer');
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, [uid]);

  const value: AuthValue = {
    session, user: session?.user ?? null, role, loading, isAdmin: role === 'admin',
    signOut: async () => { await supabase.auth.signOut(); },
  };
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth doit être utilisé dans AuthProvider');
  return ctx;
}
