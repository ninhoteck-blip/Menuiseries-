import { Link, NavLink, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useI18n } from '../i18n';
import { LangSwitch, Logo } from './ui';
import { WHATSAPP_NUMBER } from '../lib/config';

export default function ShopLayout() {
  const { t } = useI18n();
  const { isAdmin, signOut } = useAuth();
  const link = ({ isActive }: { isActive: boolean }) => `whitespace-nowrap py-1 ${isActive ? 'border-b-2 border-forest text-forest' : 'text-forest/70 hover:text-forest'}`;
  const links = (<><NavLink to="/" end className={link}>{t('nav.home')}</NavLink><NavLink to="/catalog" className={link}>{t('nav.catalog')}</NavLink></>);
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-30 border-b border-sand bg-ivory/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3">
          <Logo />
          <nav className="hidden items-center gap-7 text-sm font-medium md:flex">{links}</nav>
          <div className="flex items-center gap-2">
            <LangSwitch />
            {isAdmin && <Link to="/admin" className="hidden min-h-10 items-center rounded-full border border-forest px-4 text-sm font-medium text-forest sm:inline-flex">{t('nav.admin')}</Link>}
            <button onClick={signOut} className="min-h-10 rounded-full bg-forest px-4 text-sm font-medium text-ivory hover:bg-forest-dark">{t('common.logout')}</button>
          </div>
        </div>
        <nav className="flex gap-6 overflow-x-auto px-4 pb-2 text-sm font-medium md:hidden">{links}{isAdmin && <NavLink to="/admin" className={link}>{t('nav.admin')}</NavLink>}</nav>
      </header>
      <div className="flex-1"><Outlet /></div>
      <footer className="bg-forest-dark text-ivory">
        <div className="mx-auto grid max-w-6xl gap-6 px-4 py-10 md:grid-cols-3">
          <div><Logo light /><p className="mt-3 text-sm text-ivory/70">{t('about.body')}</p></div>
          <div className="text-sm"><h3 className="mb-2 text-lg">{t('sec.contact')}</h3><p>{t('contact.addr')}</p><p className="text-ivory/70">{t('contact.zone')}</p></div>
          <div className="text-sm"><h3 className="mb-2 text-lg">WhatsApp</h3><p>+{WHATSAPP_NUMBER}</p></div>
        </div>
        <p className="border-t border-white/10 py-4 text-center text-xs text-ivory/60">© {new Date().getFullYear()} TGG Bois. {t('footer.rights')}</p>
      </footer>
    </div>
  );
}
