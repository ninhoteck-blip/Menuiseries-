import { Link } from 'react-router-dom';
import { formatPrice, type Availability, type Product } from '../lib/data';
import { useI18n } from '../i18n';
import type { Key } from '../i18n/fr';

export function AvailabilityBadge({ value }: { value: Availability }) {
  const { t } = useI18n();
  const style = value === 'in_stock' ? 'bg-emerald-100 text-emerald-900' : value === 'made_to_order' ? 'bg-amber-100 text-amber-900' : 'bg-stone-200 text-stone-700';
  return <span className={`inline-block rounded-full px-3 py-1 text-xs font-medium ${style}`}>{t(`avail.${value}` as Key)}</span>;
}

export function ProductImage({ src, alt, className = '' }: { src: string | null; alt: string; className?: string }) {
  const { t } = useI18n();
  return src ? <img src={src} alt={alt} loading="lazy" className={`object-cover ${className}`} onError={(e) => { e.currentTarget.style.display = 'none'; }} />
    : <div className={`grid place-items-center bg-sand/60 text-sm text-wood ${className}`}>{t('product.noImage')}</div>;
}

export default function ProductCard({ p }: { p: Product }) {
  const { t } = useI18n();
  return (
    <Link to={`/product/${p.id}`} className="group overflow-hidden rounded-2xl bg-white shadow-card transition hover:-translate-y-0.5">
      <ProductImage src={p.image_url} alt={p.name ?? ''} className="aspect-[4/3] w-full" />
      <div className="space-y-2 p-4">
        <h3 className="text-lg leading-tight text-forest">{p.name}</h3>
        <p className="font-medium">{formatPrice(p.price) ?? t('product.priceOnRequest')}</p>
        <AvailabilityBadge value={p.availability} />
      </div>
    </Link>
  );
}
