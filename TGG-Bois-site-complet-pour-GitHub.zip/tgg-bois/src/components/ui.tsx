import { useState, type InputHTMLAttributes, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { useI18n } from '../i18n';

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link to="/" className="inline-flex items-center gap-2">
      <span className={`grid h-9 w-9 place-items-center rounded-xl font-serif text-lg ${light ? 'bg-ivory text-forest' : 'bg-forest text-ivory'}`}>T</span>
      <span className={`font-serif text-xl ${light ? 'text-ivory' : 'text-forest'}`}>TGG Bois</span>
    </Link>
  );
}

export function LangSwitch() {
  const { toggle, t, lang } = useI18n();
  return (
    <button type="button" onClick={toggle} aria-label={lang === 'fr' ? 'Switch to English' : 'Passer en français'}
      className="min-h-10 rounded-full border border-sand bg-white/70 px-4 text-sm font-medium text-forest transition hover:bg-white">
      {t('lang.switch')}
    </button>
  );
}

interface FieldProps extends InputHTMLAttributes<HTMLInputElement> { label: string; error?: string; }
export function Field({ label, error, id, ...rest }: FieldProps) {
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-sm font-medium">{label}</label>
      <input id={id} {...rest} aria-invalid={Boolean(error)} aria-describedby={error ? `${id}-err` : undefined}
        className="h-12 w-full rounded-xl border border-transparent bg-stone-100/80 px-4 text-base placeholder:text-stone-400 focus:border-forest focus:bg-white focus:outline-none" />
      {error && <p id={`${id}-err`} className="mt-1 text-sm text-red-700">{error}</p>}
    </div>
  );
}

export function PasswordField({ label, error, id, ...rest }: FieldProps) {
  const { t } = useI18n();
  const [shown, setShown] = useState(false);
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-sm font-medium">{label}</label>
      <div className="relative">
        <input id={id} {...rest} type={shown ? 'text' : 'password'} aria-invalid={Boolean(error)} aria-describedby={error ? `${id}-err` : undefined}
          className="h-12 w-full rounded-xl border border-transparent bg-stone-100/80 pl-4 pr-14 text-base placeholder:text-stone-400 focus:border-forest focus:bg-white focus:outline-none" />
        <button type="button" onClick={() => setShown((s) => !s)} aria-label={shown ? t('auth.hide') : t('auth.show')}
          className="absolute right-1 top-1 h-10 rounded-lg px-3 text-lg hover:bg-sand/60">
          {shown ? '🙈' : '👁'}
        </button>
      </div>
      {error && <p id={`${id}-err`} className="mt-1 text-sm text-red-700">{error}</p>}
    </div>
  );
}

export function Button({ loading, variant = 'primary', children, ...rest }: { loading?: boolean; variant?: 'primary' | 'outline'; children: ReactNode } & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const base = 'h-12 w-full rounded-xl text-base font-medium transition disabled:opacity-60';
  const style = variant === 'primary' ? 'bg-forest text-ivory hover:bg-forest-dark' : 'border-2 border-forest bg-white text-forest hover:bg-ivory';
  return <button {...rest} disabled={loading || rest.disabled} className={`${base} ${style}`}>{loading ? '…' : children}</button>;
}

export function Notice({ kind, children }: { kind: 'error' | 'success'; children: ReactNode }) {
  const style = kind === 'error' ? 'bg-red-50 text-red-800' : 'bg-emerald-50 text-emerald-900';
  return <p role={kind === 'error' ? 'alert' : 'status'} className={`rounded-xl px-4 py-3 text-sm ${style}`}>{children}</p>;
}
